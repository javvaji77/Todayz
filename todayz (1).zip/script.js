document.addEventListener('DOMContentLoaded', () => {
  console.log('Todayz app loaded');
});